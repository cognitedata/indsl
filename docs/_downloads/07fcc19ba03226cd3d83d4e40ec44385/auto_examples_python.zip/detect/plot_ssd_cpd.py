"""
====================================
Steady State Detection: Change Point
====================================

Example of steady state detection using a change point (CPD) algorithm. We use data from a
compressor suction pressure sensor. The data is in barg units and resampled to 1 minute granularity.

In the figure below it can be observed how the Steady State Detection algorithm identifies steady regions for 4 days of
process data (sampled using 1m granularity). The input parameters used by the algorithm in this example are:

    - min_distance = 60 → specifies the minimum size of valid steady state regions
    - var_threshold = 5.0 → specify the maximum variance allowed for each region
    - slope_threshold = -8.8 → specify the maximum slope (10^-8.8) allowed for each region

"""

import matplotlib.pyplot as plt
import pandas as pd

from indsl.detect import ssd_cpd


data = pd.read_csv("../../datasets/data/suct_pressure_barg.csv", index_col=0)
data = data.squeeze()
data.index = pd.to_datetime(data.index)
# TODO: Create load_pressure_data method from above

# Plot the process data
fig, ax1 = plt.subplots(figsize=(9, 7))
ax2 = ax1.twinx()
ax1.plot(data.index, data.values)
ax1.set_ylabel("Pressure (barg)")

# Evalute the Steady State Conditions with a minimum window of 60
ss_map = ssd_cpd(data, min_distance=60, var_threshold=5.0, slope_threshold=-8.8)

# Plot the Steady State regions
ln2 = ax2.fill_between(ss_map.index, ss_map.values, color="orange", alpha=0.2)
ax2.set_ylabel("Steady State Status")
ax2.set_ylim([0, 1])

# create legend
plt.legend((plt.Line2D(data.index, data.values), ln2), ("Sensor Readings", "Steady State Regions"))
plt.title("Steady State Detection based on ED Pelt Change Point Detection algorithm")
plt.show()
